WEBSITE CEK DPS PILKADES DESA DERAS 2026

Isi folder:
- public/index.html : tampilan website
- public/data.json : data nama, alamat RT/RW, dan TPS (3.264 entri)
- firebase.json : konfigurasi Firebase Hosting
- .firebaserc : ganti GANTI_DENGAN_PROJECT_ID_FIREBASE dengan Project ID Firebase Anda

PENTING:
1. Data ini berasal dari file DPS DERAS New.xlsx.
2. Website hanya menampilkan nama, alamat, dan TPS; tidak menampilkan NIK atau kolom pribadi lainnya.
3. Data DPS adalah data pribadi pemilih. Pastikan publikasi daftar ini diizinkan oleh panitia/otoritas terkait sebelum mengunggahnya ke internet.
4. Untuk Firebase Hosting melalui komputer, pasang Firebase CLI lalu jalankan:
   npm install -g firebase-tools
   firebase login
   firebase use --add
   firebase deploy --only hosting
   (Pilih project Firebase Desa Deras saat diminta.)
5. Di HP Android, cara yang lebih mudah adalah memakai GitHub + layanan deploy yang terhubung ke Firebase atau minta bantuan operator komputer untuk menjalankan perintah di atas. Jangan bagikan password Google Anda.
